﻿
document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("theme-toggle");
    const htmlTag = document.documentElement;

    toggleBtn.addEventListener("click", function () {
        const currentTheme = htmlTag.getAttribute("data-bs-theme");
        const newTheme = currentTheme === "light" ? "dark" : "light";

        htmlTag.setAttribute("data-bs-theme", newTheme);
        toggleBtn.textContent = newTheme === "light" ? "🌙" : "☀️";
    });
});


