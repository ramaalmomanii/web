﻿function gotoquestion(element) {
    localStorage.setItem("element", element);
    window.location.href = "questions.html";
}

window.onload = function () {
    const el = localStorage.getItem("element");

    document.querySelectorAll("section").forEach(sec => {
        sec.style.display = "none";
    });

    const target = document.querySelector(`.${el}`);
    if (target) {
        target.style.display = "block";
    }

};
function checkAnswers(subject) {
    const section = document.querySelector(`section.${subject}`);
    const correctAnswers = section.querySelectorAll('input.answercorrect:checked');
    const totalCorrect = correctAnswers.length;
    alert(`أجبت بشكل صحيح على ${totalCorrect} من 5 أسئلة في مادة ${subject}`);
    const lap = document.getElementById("score");

    if (totalCorrect > 2.5) {
        lap.style.color = "green";
        lap.innerHTML = "Grade " + correctAnswers.length + " out of 5 😍 ";
        
    } else {
        lap.style.color = "red";
        lap.innerHTML = "Grade " + correctAnswers.length + " out of 5 🙂 ";
    }
};

